﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Media.TextFormatting;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace bitFlags
{
	/// <summary>
	/// MainWindow.xaml の相互作用ロジック
	/// </summary>
	public partial class MainWindow : Window
	{
		/// <summary>
		/// viewModel
		/// </summary>
		private viewModel viewModel = new viewModel();

		/// <summary>
		/// コンストラクタ
		/// </summary>
		public MainWindow()
		{
			InitializeComponent();

			this.DataContext = this.viewModel;
		}

		// ビット演算を使用するメリットは、変数を一つにできるため、メモリ消費量を抑えられること
		// コンピューターとのやり取りは最終的には2進数です。2進数を使用することで、変換を抑え、速度アップが望めます（誤差レベル？）
		// ただ、使用が向かないこともあるので（可読性の問題）考えてつかう

		private void Button_Click_2(object sender, RoutedEventArgs e)
		{
			// 例として、以下のようにフラグが立っていても、一文でフラグを折ることができます。
			// FlagsのenumはByteなので、8桁
			// 〇×□△の状態　　00011110  を
			// 　　　　　　　　　　　  00000000 でビット演算（論理演算）    「a＆b」はaとbの両方が1なら1にセット、それ以外は0にセット	　「a &= b」 はaとbの論理積をaに代入
			// 　　　　　　　　結果　00000000
			this.viewModel.Flag &= Flag_Bit.none;

			// 〇の状態            00000010  を
			// ×と演算             00000100  でビット演算（論理演算）    「a|b」はaとbの少なくとも一方が1なら1にセット、両方が0なら0にセット　　　「a |= b」 ビット演算の結果を代入
			//                結果  00000110  〇×の二つが立った状態になります 
			//this.viewModel.Flag |= Flag_Bit.batu;

			// フラグを折りたいときは、折りたいビットを反転させて、「＆」で演算
			// 〇×の状態          00000110  を
			// ×の反転と演算     11111011  でビット演算（論理演算）    「~a」はaのビットを反転させます
			//                結果   00000010 　×のフラグが折れて、〇が立った状態になります 
			//this.viewModel.Flag &= ~Flag_Bit.batu;
		}

		/// <summary>
		/// ボタンイベント
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void Button_Click(object sender, RoutedEventArgs e)
		{
			this.textBlock_Output.Text = "";

			// Flagプロパティのみで複数の判定をすることができます。
			// C#の HasFlagsメソッドで引数にしたビットがあるかを判定してくれます
			// （例）変数の状態　00000110　　〇のビット　00000010 が変数に あるか判定してくれる
			// ※本来は、シフト演算で判定が必要 ビット bit に i 番目のフラグが立っているかどうか →	if (bit & (1<<i))
			// HasFlagsメソッドはC＃が判定してくれるため、遅い（誤差レベル）ので、マジの最速を目指すなら↑
			if (this.viewModel.Flag.HasFlag(Flag_Bit.maru))
				this.textBlock_Output.Text += "○";
			else
				this.textBlock_Output.Text.Replace("〇", "");

			if (this.viewModel.Flag.HasFlag(Flag_Bit.batu))
				this.textBlock_Output.Text += "×";
			else
				this.textBlock_Output.Text.Replace("×", "");

			if (this.viewModel.Flag.HasFlag(Flag_Bit.sikaku))
				this.textBlock_Output.Text += "□";
			else
				this.textBlock_Output.Text.Replace("□", "");

			if (this.viewModel.Flag.HasFlag(Flag_Bit.sannkaku))
				this.textBlock_Output.Text += "△";
			else
				this.textBlock_Output.Text.Replace("△", "");
		}


		private void Button_Click_1(object sender, RoutedEventArgs e)
		{
			// 一文で論理和を行い、複数のフラグを立てることも可能
			this.viewModel.Flag |= Flag_Bit.maru | Flag_Bit.batu | Flag_Bit.sannkaku | Flag_Bit.sikaku;

			// ↑は見慣れないが、書き方的には↓と一緒、ただ演算子を複数並べてるだけ
			var a = (byte)Flag_Bit.sikaku + (byte)Flag_Bit.batu + (byte)Flag_Bit.maru + (byte)Flag_Bit.sannkaku;
		}
	}
}
