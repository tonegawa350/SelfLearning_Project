﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
// PropertyChangedEventHandlerを使うにはこれが必要
using System.ComponentModel;
// OnPropertyChanged() の呼び出し時の引数を書かなくてもいいようにするために必要
using System.Runtime.CompilerServices;

namespace bitFlags
{
	public class viewModel : INotifyPropertyChanged // INotifyPropertyChanged を継承しなくてもPropertyChangedEventHandlerは使えるが継承されてたので  【参考】https://docs.microsoft.com/ja-jp/dotnet/framework/wpf/data/how-to-implement-property-change-notification
	{
		public viewModel()
		{

		}

		private Flag_Bit flag;

		public Flag_Bit Flag
		{
			get
			{
				return flag;
			}
			set
			{
				flag = value;
			}
		}


		// WPFのChekedイベントはなぜかチェック外した時に走らないので、プロパティのバインドで代替===================================↓
		#region
		private byte maru;

		public byte Maru
		{
			get
			{
				return maru;
			}
			set
			{
				this.maru = value;
				if (this.maru == 0)
					this.Flag &= ~Flag_Bit.maru;
				else
					this.Flag |= Flag_Bit.maru;	

				OnPropertyChanged();

			}
		}

		private byte batu;

		public byte Batu
		{
			get
			{
				return batu;
			}
			set
			{
				batu = value;
				if (this.batu == 0)
					this.Flag &= ~Flag_Bit.batu;
				else
					this.Flag |= Flag_Bit.batu;

				OnPropertyChanged();

			}
		}

		private byte sikaku;

		public byte Sikaku
		{
			get
			{
				return sikaku;
			}
			set
			{
				sikaku = value;
				if (this.sikaku == 0)
					this.Flag &= ~Flag_Bit.sikaku;
				else
					this.Flag |= Flag_Bit.sikaku;

				OnPropertyChanged();

			}
		}

		private byte sankaku;

		public byte Sankaku
		{
			get
			{
				return sankaku;
			}
			set
			{
				sankaku = value;
				if (this.sankaku == 0)
					this.Flag &= ~Flag_Bit.sannkaku;
				else
					this.Flag |= Flag_Bit.sannkaku;

				OnPropertyChanged();

			}
		}
		#endregion
		// WPFのChekedイベントはなぜかチェック外した時は走らないので、プロパティのバインドで代替===================================↑


		// OnPropertyChanged====================================================================↓
		public event PropertyChangedEventHandler PropertyChanged;

		public void OnPropertyChanged([CallerMemberName] string name = null)
		{
			PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
		}
		// OnPropertyChanged====================================================================↑
	}

	/// <summary>
	/// 2進数で持つeunm
	/// </summary>
	[Flags] // Flags属性をつけることで、HasFlagsメソッドが使用できるようになります
	public enum Flag_Bit : byte
	{
		none = 0b0,   // 0bとつけることで「2進数」と定義できます
		　　　　　　　　　　　　　　　　　　　　　　
													
		　　　　　　　　　　　　　　　　　　　　　　 //　　10進数　　　　2進数　　　　C#での2進数  　　　シフト演算　　　　　　　　　　　　【シフト演算とは】
		maru = 1 << 1,   　　　　　　　　　//　　　　2　　 　　　		10 　　　　　　 0b10　　　　　　　1 << 1　　　　　　　　　　　　　　　数値を二進数で表し、その桁を右辺の数値でそのまま移動させることです
　　　　　　　										//		　3				　	11				0b11				なし					　　　　　　　　　　　例えば、
		batu = 1 << 2,   　　　　　　　　　 //  　　　4　　 　　　 　100 　　 　　　0b100	  　　　　1 << 2　									1 << 1 の場合は　1を2進数で表すと「10」です
													//																												シフト演算した場合、一桁ずれるので「100」になります
		sikaku = 1 << 3, 　　　　　　　　　// 　　　　8　　　　　	1000　　　　　0b1000          　1 << 3

		sannkaku = 1 << 4               //		　16　　　　 10000　　　　　0b10000        1 << 4


		// 参考文献
		// https://programming.pc-note.net/csharp/bit1.html
	}


	
}
